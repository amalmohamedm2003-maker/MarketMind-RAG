from fastapi import APIRouter, HTTPException
from backend.api.schemas import AnalyzeRequest, AnalyzeResponse
from backend.rag.growth_agent import GrowthAgent
from backend.core.logging import get_logger

router = APIRouter()
logger = get_logger()

agent = GrowthAgent()

@router.post("/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest):
    logger.info(f"Received query: {req.question}")

    try:
        result = agent.analyze(req.question)

        return AnalyzeResponse(
            question=result["question"],
            answer=result["insights"],
            sources_used=result["sources_used"]
        )

    except Exception as e:
        logger.exception("Analysis failed")
        raise HTTPException(status_code=500, detail=str(e))
