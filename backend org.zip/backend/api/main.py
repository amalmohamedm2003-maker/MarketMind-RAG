from fastapi import FastAPI
from backend.api.routes import router
from backend.core.config import settings

app = FastAPI(
    title=settings.PROJECT_NAME,
    version="1.0.0"
)

app.include_router(router)

@app.get("/")
def health_check():
    return {
        "status": "ok",
        "service": settings.PROJECT_NAME
    }
