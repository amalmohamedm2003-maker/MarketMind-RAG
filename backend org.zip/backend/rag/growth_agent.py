from backend.rag.retriever import MarketingRetriever
from backend.rag.generator import generate_answer

class GrowthAgent:
    def __init__(self):
        self.retriever = MarketingRetriever()

    def analyze(self, question):
        docs = self.retriever.retrieve(question)

        context = "\n\n".join(
            [
                f"Source: {d['source']} | Channel: {d['channel']} | Metric: {d['metric']} | Text: {d['text']}"
                for d in docs
            ]
        )
        from backend.evaluation.rag_accuracy import faithfulness, relevance

        context_docs = [d["text"] for d in docs]

        faith = faithfulness(answer, context_docs)
        rel = relevance(answer, question)

        return {
            "question": question,
            "insights": answer,
            "sources_used": len(docs),
            "metrics": {
                "faithfulness": faith,
                "relevance": rel
            }
        }

        answer = generate_answer(context, question)

        return {
            "question": question,
            "insights": answer,
            "sources_used": len(docs)
        }
