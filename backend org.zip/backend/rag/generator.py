from backend.core.config import settings

def truncate(text: str, max_chars: int):
    return text[:max_chars]

def generate_answer(context, question):
    context = truncate(context, settings.MAX_PROMPT_CHARS)
    prompt = GROWTH_ANALYSIS_PROMPT.format(
        context=context,
        question=question
    )
    return router.generate(prompt)
