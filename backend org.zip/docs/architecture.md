MarketMind AI Architecture

- FastAPI API layer
- RAG intelligence layer
- FAISS vector store
- LLM router (Gemini + local fallback)
- Logging & evaluation
