Deployment Strategy

- Local CPU inference
- Cloud LLM when available
- Graceful degradation on quota failure
- Stateless API design
